# hansomeclient

A lightweight PvP client for Minecraft Java 1.21.11, built as a Fabric client-side mod.

## Features
- FPS and CPS (left | right) counters
- Keystrokes overlay (WASD, LMB, RMB)
- Armor and held-item durability HUD
- Optional coordinates
- Toggle sprint (auto-sprint while holding forward)
- Hold-to-zoom (default `C`)
- In-game menu (default `Right Shift`) to toggle every module; settings saved to `config/hansomeclient.json`

All features are client-side visual/quality-of-life only, so they are accepted on most servers.

## Build
Requires JDK 21 and Gradle.

    gradle wrapper --gradle-version 9.2.1
    ./gradlew build

The jar is created in `build/libs/hansomeclient-1.0.0.jar`.

## Install
1. Install Fabric Loader for 1.21.11 (https://fabricmc.net/use/installer/).
2. Put Fabric API and `hansomeclient-1.0.0.jar` into your `.minecraft/mods` folder.
3. Launch the Fabric 1.21.11 profile.

## If the build fails
Version numbers live in `gradle.properties`; compare with https://fabricmc.net/develop.
Mojang-mapped class names changed in several 1.21.x releases, so a compile error is most likely a renamed
class or method in `HansomeClient.java`.
