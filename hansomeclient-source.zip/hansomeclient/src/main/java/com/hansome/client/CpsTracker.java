package com.hansome.client;

import java.util.ArrayDeque;

public class CpsTracker {
	private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
	private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();

	public static void leftClick() { LEFT.addLast(System.currentTimeMillis()); }
	public static void rightClick() { RIGHT.addLast(System.currentTimeMillis()); }

	public static int left() { return count(LEFT); }
	public static int right() { return count(RIGHT); }

	private static int count(ArrayDeque<Long> q) {
		long cutoff = System.currentTimeMillis() - 1000;
		while (!q.isEmpty() && q.peekFirst() < cutoff) q.removeFirst();
		return q.size();
	}
}
