package com.hansome.client.mixin;

import com.hansome.client.CpsTracker;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public class MinecraftMixin {
	@Inject(method = "startAttack", at = @At("HEAD"))
	private void hansome$onAttack(CallbackInfoReturnable<Boolean> cir) {
		CpsTracker.leftClick();
	}

	@Inject(method = "startUseItem", at = @At("HEAD"))
	private void hansome$onUse(CallbackInfo ci) {
		CpsTracker.rightClick();
	}
}
