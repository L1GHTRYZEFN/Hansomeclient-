package com.hansome.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("hansomeclient.json");

	public boolean hud = true;
	public boolean fps = true;
	public boolean cps = true;
	public boolean coords = false;
	public boolean keystrokes = true;
	public boolean armor = true;
	public boolean toggleSprint = true;
	public boolean zoom = true;

	public static Config load() {
		try {
			if (Files.exists(FILE)) {
				Config c = GSON.fromJson(Files.readString(FILE), Config.class);
				if (c != null) return c;
			}
		} catch (Exception e) {
			HansomeClient.LOGGER.warn("Could not read config, using defaults", e);
		}
		return new Config();
	}

	public void save() {
		try {
			Files.writeString(FILE, GSON.toJson(this));
		} catch (IOException e) {
			HansomeClient.LOGGER.warn("Could not save config", e);
		}
	}
}
