package com.hansome.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class HansomeMenu extends Screen {
	public HansomeMenu() {
		super(Component.literal("hansomeclient"));
	}

	@Override
	protected void init() {
		Config c = HansomeClient.CONFIG;
		int w = 180, h = 20, x = this.width / 2 - w / 2, y = this.height / 2 - 100;
		y = toggle("HUD", () -> c.hud, v -> c.hud = v, x, y, w, h);
		y = toggle("FPS", () -> c.fps, v -> c.fps = v, x, y, w, h);
		y = toggle("CPS", () -> c.cps, v -> c.cps = v, x, y, w, h);
		y = toggle("Coordinates", () -> c.coords, v -> c.coords = v, x, y, w, h);
		y = toggle("Keystrokes", () -> c.keystrokes, v -> c.keystrokes = v, x, y, w, h);
		y = toggle("Armor status", () -> c.armor, v -> c.armor = v, x, y, w, h);
		y = toggle("Toggle sprint", () -> c.toggleSprint, v -> c.toggleSprint = v, x, y, w, h);
		toggle("Zoom", () -> c.zoom, v -> c.zoom = v, x, y, w, h);
	}

	private int toggle(String name, BooleanSupplier get, Consumer<Boolean> set, int x, int y, int w, int h) {
		this.addRenderableWidget(Button.builder(label(name, get.getAsBoolean()), btn -> {
			set.accept(!get.getAsBoolean());
			btn.setMessage(label(name, get.getAsBoolean()));
			HansomeClient.CONFIG.save();
		}).bounds(x, y, w, h).build());
		return y + h + 4;
	}

	private static Component label(String name, boolean on) {
		return Component.literal(name + ": " + (on ? "ON" : "OFF"));
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		super.render(graphics, mouseX, mouseY, partialTick);
		graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 120, 0xFFFFFFFF);
	}

	@Override
	public void onClose() {
		HansomeClient.CONFIG.save();
		super.onClose();
	}
}
