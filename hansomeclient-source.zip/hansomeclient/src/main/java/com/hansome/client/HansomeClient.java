package com.hansome.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HansomeClient implements ClientModInitializer {
	public static final String MOD_ID = "hansomeclient";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static Config CONFIG;

	private static KeyMapping zoomKey;
	private static KeyMapping menuKey;

	public static boolean isZooming() {
		return CONFIG != null && CONFIG.zoom && zoomKey != null && zoomKey.isDown();
	}

	@Override
	public void onInitializeClient() {
		CONFIG = Config.load();

		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
		zoomKey = KeyMappingHelper.registerKeyMapping(
				new KeyMapping("key.hansomeclient.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, category));
		menuKey = KeyMappingHelper.registerKeyMapping(
				new KeyMapping("key.hansomeclient.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (menuKey.consumeClick()) {
				mc.setScreen(new HansomeMenu());
			}
			// Toggle sprint: hold sprint automatically while moving forward
			if (CONFIG.toggleSprint && mc.player != null && mc.screen == null && mc.options.keyUp.isDown()) {
				mc.options.keySprint.setDown(true);
			}
		});

		HudElementRegistry.attachElementAfter(
				VanillaHudElements.MISC_OVERLAYS,
				Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
				HansomeClient::renderHud);

		LOGGER.info("hansomeclient loaded");
	}

	private static void renderHud(GuiGraphics g, DeltaTracker tick) {
		Minecraft mc = Minecraft.getInstance();
		if (!CONFIG.hud || mc.player == null || mc.options.hideGui) return;
		Font font = mc.font;

		int y = 4;
		if (CONFIG.fps) {
			g.drawString(font, mc.getFps() + " FPS", 4, y, 0xFFFFFFFF, true);
			y += 10;
		}
		if (CONFIG.cps) {
			g.drawString(font, CpsTracker.left() + " | " + CpsTracker.right() + " CPS", 4, y, 0xFFFFFFFF, true);
			y += 10;
		}
		if (CONFIG.coords) {
			String pos = String.format("XYZ: %.0f %.0f %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
			g.drawString(font, pos, 4, y, 0xFFFFFFFF, true);
			y += 10;
		}
		if (CONFIG.keystrokes) {
			renderKeystrokes(g, mc, 4, y + 4);
		}
		if (CONFIG.armor) {
			renderArmor(g, mc, font);
		}
	}

	private static void renderKeystrokes(GuiGraphics g, Minecraft mc, int x, int y) {
		int s = 20, gap = 2;
		key(g, mc, "W", mc.options.keyUp.isDown(), x + s + gap, y, s, s);
		key(g, mc, "A", mc.options.keyLeft.isDown(), x, y + s + gap, s, s);
		key(g, mc, "S", mc.options.keyDown.isDown(), x + s + gap, y + s + gap, s, s);
		key(g, mc, "D", mc.options.keyRight.isDown(), x + 2 * (s + gap), y + s + gap, s, s);
		int bw = (3 * s + 2 * gap - gap) / 2;
		key(g, mc, "LMB", mc.options.keyAttack.isDown(), x, y + 2 * (s + gap), bw, s);
		key(g, mc, "RMB", mc.options.keyUse.isDown(), x + bw + gap, y + 2 * (s + gap), bw, s);
	}

	private static void key(GuiGraphics g, Minecraft mc, String label, boolean down, int x, int y, int w, int h) {
		g.fill(x, y, x + w, y + h, down ? 0xAAFFFFFF : 0x80000000);
		int color = down ? 0xFF000000 : 0xFFFFFFFF;
		g.drawString(mc.font, label, x + (w - mc.font.width(label)) / 2, y + (h - 8) / 2, color, false);
	}

	private static void renderArmor(GuiGraphics g, Minecraft mc, Font font) {
		EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
				EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND};
		int x = g.guiWidth() - 22;
		int y = g.guiHeight() / 2 - 56;
		for (EquipmentSlot slot : slots) {
			ItemStack stack = mc.player.getItemBySlot(slot);
			if (!stack.isEmpty()) {
				g.renderItem(stack, x, y);
				g.renderItemDecorations(font, stack, x, y);
				if (stack.isDamageableItem()) {
					String d = String.valueOf(stack.getMaxDamage() - stack.getDamageValue());
					g.drawString(font, d, x - font.width(d) - 2, y + 4, 0xFFFFFFFF, true);
				}
			}
			y += 18;
		}
	}
}
